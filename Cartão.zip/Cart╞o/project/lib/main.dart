import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    var children;
    return Scaffold(
      body: Column(
        children: [
          SizedBox(
              height: 60,
              child: Container(
                color: Colors.blue,
              )),
          SizedBox(
            height: 40,
            child: Container(
              color: Colors.white,
              child: Text('CARTÃO DIGITAL'),
            ),
          ),
          CircleAvatar(
            radius: 110,
            backgroundImage: AssetImage('Assent/image/foto.png')
          ),
          Container(
            child: Padding(padding: const EdgeInsets.all(5.0)),
          ),
          Container(
            child: Column(
              children: [
                Text("LUCAS BARTL RODRIGUES ",
                    style: TextStyle(
                      fontSize: 35,
                    )),
                Container(
                  child: Padding(padding: const EdgeInsets.all(5.0)),
                ),
                Text(
                  " TECNICO EM INFORMATICA",
                  style: TextStyle(
                    fontSize: 20,
                  ),
                ),
              ],
            ),
          ),
          Container(
            child: Padding(padding: const EdgeInsets.all(5.0)),
          ),
          ElevatedButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.green),
                shape: MaterialStateProperty.all(
                  RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(100),
                  ),
                ),
              ),
              onPressed: () {},
              child: Column(
                children: [
                  Text(
                    "WHATSAPP",
                    //stle: TextStyle(backgroundColor: Colors.green),
                  ),
                ],
              )),
          Container(
            child: Padding(padding: const EdgeInsets.all(5.0)),
          ),
          Container(
            child: Column(
              children: [
                Text(
                  "ENTRE EM CONTADO ATRAVES DO EMAIL LUCAS.BARTLLB@GMAIL.COM",
                  style: TextStyle(
                    fontSize: 20,
                    backgroundColor: Colors.white,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(
                      "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAWMAAACOCAMAAADTsZk7AAACDVBMVEX////IMSs7WZgAe7UAc7FcbLMAdrMAcbA4V5fI3OrA1ufh5O0qTpPIzt5LZZ8oTJIAxflFxlUAwfctuENSzl8ihLpKyVnJJR7HDAAAxvkAvfXOPzpUz2DJIhnaqqjUj41odriHlbqMt9UAsvEAuPMAzfw5v0wAZ6v19fXo9Pmryd/y+vx4ZKmzQo/WRW1wZ6zHMoPSQXLcS2Po6Oi/NIlidqisSJLLOXzOVlPXRmvhT1z7xWm4PY3GMYUYQIrdTGHiUVjygEb0p1WGX6OhUJfPPnfjpaPxXz3nVVDycULzlE30nlEAq+/2slx0ZquQWp/j0OLvzMvYf3zsWEjyeERJXKyHTpqlhbaZVpygPY7O79EyxETt+e6K2ZLd89/3396w4rXMSUXQ8f3zfVXmy8oAriP+9en8yWz+7tVDlsR+isGnrtOSocCTmsi8wt3NbmxjUqFtga2m5atu13eqmcOWaac9UqfQu9SX4J25m8Lt3eu0a6WO5v5j3v668P/IjbekKYXescy2Wpven8LDUJWHRZWNcK3Zha+weKvTY5rDCnHvytqwCHxgzWzJGGfkpsLQd6nPToraZovFlr3ib3/OIWDncnnhMjXigZXXLU/veG3qm6TYibXkYmzuSSrtZljfNUPxXSv1mnb4uaT6zsD2r47xfyrya1Pzmz74yJr5yJL4wKv0rmf+0mrzlENo8jCcAAAOdklEQVR4nO2ciVsT1xbAB0UIArJKEjFQ2Zw0BTfUYMGtGNTW1gShQoBAbHCpgkt91TagtlpbEe2z8qy2dWl9fdr29W9859w7M5nlzpBpYvF93/l9nzhzs0zyy+Hcc25mkCSCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCIAiCeK0oObnaHU2mJ5CnzryxCKc+Lrcct/T01lVZsvV0qfnRHzWG6xcjHPvoVUlzR8n65S4pPql/vHxmYGDFihUbOCvsGFgxZTzuuooyT9aUVZw2PLihwOctWBxvwNvwygVmwWq3ipcvLyrJPLx8YIMAoeVTsu6w6yqWucFjkDzty0IwxxfWH3WJKHLvuDDjeOrshg3vA2+p4I6t58xvfHmZK8Ug2ZPJNuFA1oohlieWXnJOjsvPqm7fYWRMCzW/oR11q8fRp8ezzHwHzzn1sdNuFIPk8KIORobHzwPDY3l2q5KLY/msKtcME22xPHBGeWCpx9axp2KnZ9WqZcvKKkzZpEx5bEP2iYITaHQUMDy6Nh6vqwWq4nUXxkdeM8efKEY/QAYHL35o4pNTpzYM6CX/Q8kWpXbZ2LNz61RQefYp450q+Kjs0jBG8hb7tz++Nr5WTzw+qkRzHlNMLo4HFb3AjYufWuorRunH+mBWAtnOsadMV+OJHTe4yxQskCN2b37YZBipjV/Kh1c9OTg+PIh2jyI3PrU/AlR3mWzBh2wcezz6z0nseDqbos2EXUYetRpGqmqHc7VqxOB4fVFxcfaOLx/l9Pb2fsZkfnbYDHc2pUkeKHVyvNPQqYgduzcMCH/vR9bWCRVjxhh3qzE5m8zKcdFqSIVvLi5ZdXyR++3tHcL3cPjzq0MavTeAQeQTvG3qrOq43MFx2TrDKxM7djvjIQFRvzcSr7VTDJLPuxEcSrciM4rmWSfHIRxYXLLq+HMmeNu2q4dh58rVbRpsHCOcTYV46xmlxBiYcnBsDGOpPH+Oo4YnlhXFDthGcjJoHZttVUlLUnAWf9o5LuQLEaHC7B0zo+1XYPvbq+0qGc+YqG8wyfL7XLJTHHtWaS+qtBw4XZY3x4KOem2dk+Pa2viw9nHomWl1UAyhPNPqt94j47hYWezJOld8gYLb269CMr52u1tF84yWL28p/XBwEF7px2eZZEfHapche3ZWAKZWML+OR6u4SYhYO8kjAslB0Gh6pmSriaBkTs26XMHXehZfJNIcg0yQ+gVs3u7MoIgGy0Nf490uDl4Gq2ffQsmOjtV0fE7YaOfLMbM2zM3GsRa2kVx1QeA4ySXqmTEpTqYtyULnuPhN2A8tvkikOQaZ4PRLDOPOHgbs3u7svn79OnreNsQqustHb8DPr1jjt8LBsTblrRI2gXl1XFuHMMXSeLxOSFxQwSX9qFE/qQXNYez3O+RjXLVsalq+eMGsOr7Owvb2nCTd7NnI6enZeJfXcYevgGXM1NLXR2/A0IfvMMlL7ljOaG1Tigcbx1Xz2v1Njv0zmVCe9ZsdWxQb6ori9QCWFcUc2IB9PiR2DKF7Cxx/oyjeeOtL3bu5crv7miR/N9Q7BLPe5XeYZIe64m90rISxsjYxWmUTyNY1oiCEKdKaVi2n/SYslZuxrggFgRAmDdwKBdcvbyqBjZVNxUVCxz0Yvszxds6dOcNzw0wICWNbL+aMy4Mo+ewri2Ovz4LXzvFYPBOn2q6VtlHtQ9GYUUxW+pVqOF1pVGytKsR1RfFK/qGt1u51slDg+J9gePt2dHxvH0NRPPfjzbtzmmSY/LjjD1Cy2DH7sqNCdcx3zaKdHQdi0Wg0kUjIDNiA3VjA6pgZu9TGHI+qgxfsAtnqOFmtyqys9s+kZ5Mmx5UuHZfovu9YLXKsxS463rTpzl0cvXvnDoi/tfEa7nzbiZLR8XfQkIBkoWPPVob6Vcc5vmsKZ5Nj8BfILF14Y4K3JjV6xY7rqpA2zfH5eJUQlixMlUW6Wie0srraFMZuHespKRY6VoL33iYGvpzvF1hIg2ZMzZ/1QCnXfhUd9zLJh0WOd1q/UUXVDo690w0T3kijJtmXSDRGIo0JvEdUW2ZL+ISORxSlaq4I1YkVV1mbvdnZULrSkRwcSycFjln0LqDjDqDrBxibW0DZzDLLHNehnOu+Oscco2QXjh3juF6KTEgxzbFXigYA1jM3erWnEOeKYcWxOuddaLNxbE3IyTX+Vr+T4mpzi+LGcVOR1THq7EDH97uAhxhF8H9Hh6L5Jux/iSVzJ+QNKC9A8mD2jmXHPg8Cd1qq900o+aIebgkrS5iRAqYFX82Es+NxNnTJJlOoka53HMTs4MQaQVnh7DhUslKtUVYWWxxDhoDo7YI3c38zAkPRh2iba953BwbmbkFjchscXxnq7XXluHSnk+NAoxRN+ODQ9RHJK8UmuOOIT/JFI/XwCcgBHygPW+sKSZd+2ZwGxbKt4yqzY2mm2pk1oiVOJ8clWDAro7oWW3PcwcIXfkHv70JgKPIQZSuWF2R0DH0Jd7wNJLtwXO7ouKAAksK0FJYjjZJXjoUVx150HEj4oo31si+qLuhnHMtGx7wJmbfNFW0Wx8k1zo4rBe/E0TG7bT2P5KDAcVcXCGWOdyDoeAe45po7OhTH0P2h43Z0fCNvjiGGJ2KSLyFwjD9iE9HFHVelWJcxEreRLHAspVscw1iUjh3rY6aVrWLAjjVXoOFduzAN/2s3AkPRpyibae7qWoCBOSjkuONuXIlTvpPKxrFpid5SuzXIPgfHjYGJCYFjJmw83qbCkoE0nGoTY80VKNkhlFuE34Zk6zhkdfwTGN6x4yk63o/AhvwAXCuWu76H+9yFKm77LXD8I7R8IFnomOMx9nmL9CC+BjmQcazm40wchyFfC/Ixn/M0ifFRo+SaqrjesWDFAtcs1tjiFynOyTEY3r37KeSKR6i4HyunGGwwzbs2szrj3qZ9iuNOteMTOGY+3fXSvig6nsB8HJZiWFdMh6WGAhnzsazmY3FdMaYL29Q4Gx6riSt7YxfiNdoncF7gODk7O2OnuEVUVeTmGAzv3v8AVD7qRx7hC+rvVyw/xHI5AeXyPsVxt73jZX/FseT1wtuHpJyQYgG4JTwhRX1hdIyVXcA3IdvUx1KNLlRTfAVzZDRVo0T1GG5mbjOHcbClpcVOsTiMc3IMhvfvf4Bx3Nff19f3GAM58eQBs/wUFUvfd3VApXyHOe7UVpTzsiYUxkQQm/B6pwvC9T4wIctYFCdkOSFj1orKkhwQO55vs0pGtdoi0TyXnBoROMaEbKNYnI1zc4wJov8xxnEfhw3//uTx4wcx3tZCuQySmeMeXLrIo+MCr/bPa3OaSsTG8XhKJFnKnIal5GdhOpYkf4sNwqIiZ8f93PGxvgNI3zHjc0efwswHhfIdtoyPgdyeR8cGfJGEbLAB4RzJ1CC6cfxhrCOUnKyDfwh8XHBuxoxYcbWN4lwcPwHDkCHQ8YEjjAPHJg2Kd+xikrHdvrmx51U6Lgj4fL6AuhLnDbDdAjvHozVGyfOmMwnZ7TU1wlSBJFsxM5hYIzgtIB+OIT88A8c/H9nDOXLkF/VFJWJPYebbhd2I6rizu/uVOXbC4njEVBDXpM7rLfObhVWFSihtcWyrOCfHmIIPPHsuSb/s0Thy5Offnz9//ssTLDB2Y6HcxRq+bzZiIHfPLbVjJZBTNUZSNaPaN0vDyhi7t9hx0N9sFNzsoDgXx/8Bw5Ak/i1Jk78eVEHNz4A+XsTxbAGvFds9COTXxLHUVmMh1XYeZ78xxT+fCoWn1Sb9zc0Gx83N1SF7xbk5BsV79hyEzT/e5aiWYf5jklm2eDjHemoM5M6ld8wlV1kdg1aGss3Xjo1hPAuk/S3vNZuxfhedL8dc8a+QLCZf7GVwzXrJkC3uS/htFA/k18AxMmbOFRbq2P1MYRxMt7xnFdzsdzhn0+i4sEkKAcwxboRUx3yn0OL4GFN88N13YfuEIhk1c8l9TDIE8k+4/Lbwejk+v5jjNtGZWBhqs9VGv++1zCxi2HgOSxFD2ygyD5sdc8V7X7yEnclDLyySMZAf4MqQhN0eSxbXlsRx1PSmpXlnwylFsXDCC6YrIZoZzdXppFMiFjjOEtXxz1zxXi5ZOvHbIYBZ1iQ/+oH1e/c7cNkCAvn20sSx+fzjkHMYq021/XUkwSTiUErky/HviuK9h/a+dDpE4idsRLhjOVfHf+FSBetFN8MpnOBq5udFrlNq3+dwqY47cnCc+FVRDPxxwu4AcgQbEZ4sejqlXB2H/4Jjy2WQo6nU/KVhyAfjNZZCOTU6kmfFOV3XxMP4EOftlycmTeDpOrH9TzOOb13L2XHE/XVNhhNc+IlCw1pbNz6vlWssttWGT86f4pwcn/hTVfw2h9vGjPznn5iQHz/G0oI7ZslCcnDsWVfKWSVSrDpOuE/IhnRsncZGxkereGE8P671evlUnNu1vL8ZFaua2bSnzHq81+vqYmv16imHsjBUy3ZyhGHsWaY8NuY2I3un3VvZkteLrHO7Jv2PvZri48ePGxwfVMu33Tt2bObLyHe1x61zul5aiEc9G06ud+s4oXu7OneybGdySz6DWMrV8SSTzA0bJOsdK8lCp9jpgmkbxcs0Hx+5y8g+Q+GmPAv6xa9OBJblfBuWpKZFL2OyUKSvC1++0Dk+nglks+OFTYZzk0vFGcHOsKdMdwVqIqs/EKIEsc96bR5YlPXbsvim/BE6WegSZQFDZfIlyxT/RRTH2JawSe+ZMuk93HxvznTc0q1lLjhnuBh7SziQnWVvIJwwHlYgEWJa41X9rYuSle6wdjeTJwQ8R6KchOCw/CK87LD+OaHpem8g4HUCbq6ftgTx0v/BkP8j5ES0odGJSEOChBIEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRAEQRDE38X/AJST4zCXaImJAAAAAElFTkSuQmCC"),
                ),
              ),
            ),
          ),
          SizedBox(height: 100, child: Container(color: Colors.blue)),
        ],
      ),
    );
  }
}
